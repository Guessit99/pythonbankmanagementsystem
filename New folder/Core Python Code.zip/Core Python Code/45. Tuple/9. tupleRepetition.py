a = (1, 2, 3)

print(a)

result = a * 3

print(result)