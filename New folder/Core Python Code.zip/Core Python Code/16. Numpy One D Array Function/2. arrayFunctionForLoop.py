# 1D Array using array Function Numpy
from numpy import *
stu_roll = array([101, 102, 103, 104, 105])

for element in stu_roll:
	print(element)