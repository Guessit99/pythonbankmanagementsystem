# 1D Array using array Function Numpy
from numpy import *
stu_roll = array([101, 102, 103, 104, 105])

n = len(stu_roll)
for i in range(n):
	print('index',i,"=",stu_roll[i])