a = 5
b = 2
value = a/b
print(type(value))
int_value = int(value)
print(int_value)
print(type(int_value))

# String to Integer
q = 20
u = '10'
print(type(u))
r = q + int(u)
print(r)

# Float to Integer
n1 = 10.36
vn1 = int(n1)
print(vn1)
print(type(vn1))

# Integer to Float
n2 = 10
vn2 = float(n2)
print(vn2)
print(type(vn2))

# Integer to Complex
n3 = 10
vn3 = complex(n3)
print(vn3)
print(type(vn3))

# Integer to String
n4 = 10
vn4 = str(n4)
print(vn4)
print(type(vn4))

# String to Tuple
n5 = "GeekyShows"
vn5 = tuple(n5)
print(vn5)
print(type(vn5))

# Tuple to List
n5 = ("Rahul", "Ram", "Sonam", "Preet")
vn5 = list(n5)
print(vn5)
print(type(vn5))