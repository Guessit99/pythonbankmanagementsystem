print("$" * 7)

str1 = "GeekyShows "
print(str1 * 5)

print(str1[0:4]* 3)

