str1 = "GeekyShows"
str2 = "GeekyShows"
str3 = "Python"
str4 = "A"
str5 = "B"
result1 = str1 == str2
result2 = str1 == str3
result3 = str4 < str5
print(result1)
print(result2)
print(result3)

