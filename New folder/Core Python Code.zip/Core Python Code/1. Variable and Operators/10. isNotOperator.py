a = 10
b = 10
print(a is not b)

a = 10
b = '10'
print(a is not b)