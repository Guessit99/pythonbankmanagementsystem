st1 = "Welcome to geekyshows"
print("to" in st1)

st2 = "Welcome top geekyshows"
print("to" in st2)

st3 = "Welcome to geekyshows"
print("subs" in st3)
