st1 = "Welcome to geekyshows"
print("subs" not in st1)

st2 = "Welcome to geekyshows"
print("to" not in st2)

st3 = "Welcome top geekyshows"
print("to" not in st3)
