# Assignment operators
a = 10
b = 20
m = 15

y = a + b
print(y)

m+=10
print(m)

#m-=10
#print(m)

#m*=10
#print(m)

#m/=10
#print(m)

#m%=10
#print(m)

#m**=2
#print(m)

#m//=10
#print(m)
