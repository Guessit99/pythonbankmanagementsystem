# sorted() Function
b = [10, 20, 30, 5]
c = (10, 20, 30, 6, 40)
d = {10, 20, 30, 9,  40, 50}
e = {101:'Rahul', 102:'Raj', 103:'Sonam', 2:'Jay'}
f = [[10, 20], [60, 70], [2, 4], [30, 40]]
g = [(101, 'Rahul'), (102, 'Raj'), (2, 'Jay'), (103, 'Sonam')]
print(sorted(b))
print(sorted(c))
print(sorted(d))
print(sorted(e))
print(sorted(f))
print(sorted(g))