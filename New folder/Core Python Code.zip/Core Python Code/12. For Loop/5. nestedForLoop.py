# Nested For Loop
for i in range(3):
		print("Outer Loop", i)
		for j in range(5):
			print("Inner Loop", j)
print("Rest of the Code")