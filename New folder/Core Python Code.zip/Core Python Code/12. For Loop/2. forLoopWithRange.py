# For Loop with Range
st = "GeekyShows"
n = len(st)
for i in range(n):
	print(i, "=", st[i])

print("Rest of the Code")