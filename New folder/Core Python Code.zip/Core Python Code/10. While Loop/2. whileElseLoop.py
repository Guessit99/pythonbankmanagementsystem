# While Else Loop
a = 1
while a<=10:
	print(a)
	a+=1
else:
	print("While Condition FALSE So Else Part Executed")
print("Rest of the Code")