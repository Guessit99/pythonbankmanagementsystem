# Integer
print("******** Integer *********")
a = 10
b = 20
print(f"{a}")				# empty expression not allowed
print(f"{a} {b}")
print(f"{b} {a}")

#Float
print("******** Float *********")
c = 10.56
d = 20.42
print(f"{c}")
print(f"{c} {d}")
print(f"{d} {c}")

#String
print("******** String *********")
f_name = "Geeky"
l_name = "Shows"
print(f"{f_name}")
print(f"{f_name} {l_name}")
print(f"{l_name} {f_name}")

# Integer and String
name = "GeekyShows"
age = 10
print(f"Hello My Name is {name}")
print(f"{name} {age}")
print(f"{age} {name}")


