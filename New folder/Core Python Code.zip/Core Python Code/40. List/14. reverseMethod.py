#reverse() Method
a = [10, 20, 30, 10, 90, 'GeekyShows']

print("Before Reverse:", a)

a.reverse()

print("After Reverse:", a)

for element in a:
	print(element)