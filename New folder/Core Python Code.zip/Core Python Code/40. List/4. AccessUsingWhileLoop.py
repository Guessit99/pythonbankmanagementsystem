# Accessing List using while loop
a = [10, 20, -50, 21.3, 'Geekyshows']

print("Accessing List using while Loop")
n = len(a)
i = 0
while i < n:
	print(i, "=", a[i])
	i+=1