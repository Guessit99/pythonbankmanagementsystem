#pop() method

a = [10, 20, 30, 10, 90, 'Geekyshows']

print("Before POP:", a)

a.pop()

print("After POP:", a)

for element in a:
	print(element)

