# Creating Empty List using list Function
a = list()
print(a)
print(type(a))

# Creating list using list Function and range function
b = list(range(0, 5))
print(b)
print(type(b))



