#clear() Method
a = [10, 5, 90, 10, 30]

print("Before Clear",a)

a.clear()

print("After Clear",a)
