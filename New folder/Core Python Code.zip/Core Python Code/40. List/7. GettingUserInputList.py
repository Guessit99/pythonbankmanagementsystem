
a = []

n = int(input("Enter Number of Elements: "))

for i in range(n):
	a.append(int(input("Enter Element:")))
	
print("List:")
for element in a:
	print(element)

