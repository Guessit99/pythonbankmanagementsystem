print("****** startswith Function ******")
name = "Hi How are you"
str1 = name.startswith('Hi')
print(name)
print(str1)

print("****** endswith Function ******")
name = "Thank you Bye"
str1 = name.endswith('Bye')
print(name)
print(str1)