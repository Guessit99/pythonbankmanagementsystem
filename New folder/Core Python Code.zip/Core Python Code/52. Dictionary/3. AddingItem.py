# Adding new item to Dictionary

stu = {101: 'Rahul', 102: 'Raj', 103: 'Sonam' }
print("Before Adding:")
print(stu)
print(id(stu))
print()

stu[104] = 'GeekyShows'
print("After Adding:")
print(stu)
print(id(stu))
print()



