# Dictionary - clear() Method
stu = {101: 'Rahul', 102: 'Raj', 103: 'Sonam' }
print("Before Clearing:")
print(stu)
print()

stu.clear()
print("After Clearing:")
print(stu)