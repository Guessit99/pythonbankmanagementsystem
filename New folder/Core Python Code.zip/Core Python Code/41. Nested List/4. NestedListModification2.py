# Nested List - Modification
a = [[10, 20, 30], [40, 50, 60]]
print("Before Modification A:",a)
print()
a[0][1] = 2
a[1][2] = 6
print("After Modification A:",a)