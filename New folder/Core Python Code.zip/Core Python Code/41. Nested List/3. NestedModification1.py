# Nested List - Modification
a = [10, 20, 30, [50, 60]]

print("Before Modification A:",a)
print()
a[1] = 100
a[3][0] = 5
print("After Modification A:",a)