# index (element)
from array import *
stu_roll = array('i', [101, 102, 101, 104, 105])
print(stu_roll.index(104))