from numpy import *
a = array([25, 81, 49, 64])
b = array([[4, 9, 16, 25], [36, 16, 4, 49]])
print()
#sum() Function
print("a:",sum(a))
print("b:",sum(b))
print()
#prod() Function
print("a:",prod(a))
print("b:",prod(b))
print()
#sqrt() Function
print("a:",sqrt(a))
print("b:",sqrt(b))
