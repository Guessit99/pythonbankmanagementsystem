#Positional Arguments
#Example 1
def pw(x, y):
	z = x**y
	print(z)
	
pw(5, 2)

#Example 2
def pw(x, y):
	z = x**y
	print(z)
	
pw(2, 5)

#Example 3 will show Error
#def pw(x, y):
#	z = x**y
#	print(z)
	
#pw(5, 2, 3)
