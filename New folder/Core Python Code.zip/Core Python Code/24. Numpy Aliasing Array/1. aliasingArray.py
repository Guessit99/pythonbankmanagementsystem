from numpy import *

a = array([10, 20, 30, 40, 50])
b = a
print(a)
print(b)
print("a", id(a))
print("b", id(b))
