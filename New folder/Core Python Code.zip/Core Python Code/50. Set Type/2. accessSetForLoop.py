# Access Set using for loop

#Cretaing Set with elements
a = {10, 20, 'GeekyShows', 'Raj', 40}

for i in a:
	print(i)